<?php 
$con=mysql_connect('localhost','root','') or die("could not connect to SQl server");
mysql_select_db("college") or die("could not connect to DB");





 ?>